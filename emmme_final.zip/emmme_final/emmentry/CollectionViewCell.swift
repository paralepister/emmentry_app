//
//  CollectionViewCell.swift
//  collectionTest
//
//  Created by paralepister on 09.04.2020.
//  Copyright © 2020 paralepister. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet var cellView: UIView!
    
    @IBOutlet var cellBackImage: UIImageView!
}
