//
//  TableViewCell.swift
//  collectionTest
//
//  Created by paralepister on 09.04.2020.
//  Copyright © 2020 paralepister. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
